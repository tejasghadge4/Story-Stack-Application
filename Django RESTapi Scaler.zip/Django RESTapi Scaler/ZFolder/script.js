const textInput = document.getElementById('textInput');
const fontSize = document.getElementById('fontSize');
const fontFamily = document.getElementById('fontFamily');
const fontColor = document.getElementById('fontColor');
const position = document.getElementById('position');
const imgHeight = document.getElementById('imgHeight');
const imgWidth = document.getElementById('imgWidth');

const brightness = document.getElementById('brightness');
const invert = document.getElementById('invert');
const grayscale = document.getElementById('grayscale');
const saturate = document.getElementById('saturate');
const borderRadius = document.getElementById('borderRadius');

const outputText = document.getElementById('outputText');
const outputImage = document.getElementById('outputImage');

function updateStyles() {
  outputText.textContent = textInput.value;
  outputText.style.fontSize = fontSize.value + 'px';
  outputText.style.fontFamily = fontFamily.value;
  outputText.style.color = fontColor.value;
  outputText.style.position = position.value;

  if (imgHeight.value) outputImage.style.height = imgHeight.value;
  if (imgWidth.value) outputImage.style.width = imgWidth.value;

  outputImage.style.filter = `
    brightness(${brightness.value})
    invert(${invert.value})
    grayscale(${grayscale.value})
    saturate(${saturate.value})
  `;
  outputImage.style.borderRadius = borderRadius.value + 'px';
}

[
  textInput,
  fontSize,
  fontFamily,
  fontColor,
  position,
  imgHeight,
  imgWidth,
  brightness,
  invert,
  grayscale,
  saturate,
  borderRadius
].forEach(el => el.addEventListener('input', updateStyles));
